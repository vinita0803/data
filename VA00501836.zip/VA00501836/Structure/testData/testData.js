//This file contains test data required for test scripts

exports.Login_TC1 = {
    Email: 'test_script@gmail.com',
    Password: 'Test@123',
    IDNumber:'1234567887654321'
  }

  exports.Login_TC2 = {
    Email: 'test_script@gmail.com',
    Password: 'Test@123',
    IDNumber:'1234567887654321'
  }