var modules = require('../../config/requiredModules.js');
var client = modules.webdriverio.remote(modules.config);

var LaunchApplication = function() {

	return client
	 .init()
	 .waitForExist(modules.androidOR.launchPage_pushOKBtn,10000)
    .then(function()
    {
      return client
             .touchAction(modules.androidOR.launchPage_pushDismiss,'tap')
             .touchAction(modules.androidOR.launchPage_pullDownImage,'tap');

    }).catch(function(ex)
    {
    	return client
    	       .touchAction(modules.androidOR.launchPage_pullDownImage,'tap')
    	       .touchAction(modules.androidOR.launchPage_pushDismiss,'tap');
    });
}

var Login = function(){
	return client
	 .waitForExist(modules.androidOR.loginPage_signInLink,10000)
	 .then(function()
	{
	console.log("Signing In");	 
	return client
	 .touchAction(modules.androidOR.loginPage_signInLink,'tap')
	 .setValue(modules.androidOR.loginPage_emailTb,modules.testData.Login_TC1.Email)
	 .setValue(modules.androidOR.loginPage_passwordTb,modules.testData.Login_TC1.Password)
	 .touchAction(modules.androidOR.loginPage_signInBtn,'tap');
    }).catch(function(ex)
   {
    	console.log("Already Signed In");	
    	return client
	       .touchAction(modules.androidOR.pg_Landing_myAvatar,'tap');
   });
 
}

var Photopass = function(){
	return client
	 .waitForExist(modules.androidOR.pg_Landing_myAccountLink,20000)
	 .then(function()
	{
	console.log("Scrolling to PhotoPass");	 
	return client
	.pause(2000)
	 .swipeUp(modules.androidOR.pg_Landing_refreshLink,2000,10)
	 .waitForExist(modules.androidOR.pg_Landing_linkandview,10000)
	 .touchAction(modules.androidOR.pg_Landing_linkandview,'tap')
	 .touchAction(modules.androidOR.pg_PhotoPass_linkPhotos,'tap')
	 .touchAction(modules.androidOR.pg_linkYourPhotos_enterId,'tap')
	 .setValue(modules.androidOR.pg_linkYourPhotos_idtb,modules.testData.Login_TC1.IDNumber)
	 .touchAction(modules.androidOR.pg_linkYourPhotos_submitbtn,'tap')
	 .pause(5000)
	.then(function()
	{	
	 console.log(client.getAttribute(modules.androidOR.pg_PhotoPass_messageContainer,'text'))
	 return client.back()
	 .pause(3000)
	 .swipeDown(modules.androidOR.pg_Landing_linkandview,2000,10)
	 .touchAction(modules.androidOR.pg_Landing_myAccountLink,'tap')
	 .touchAction(modules.androidOR.pg_signOutLink,'tap')
	 .touchAction(modules.androidOR.launchPage_pushOKBtn,'tap');
	//console.log(client.getText(modules.androidOR.pg_PhotoPass_messageContainer));
	})
	}).catch(function(ex)
  {
   	console.log(ex);	
  });
}

var CloseApp = function(){
	return client.closeApp();
}

exports.LaunchApplication = LaunchApplication;
exports.Login = Login;
exports.PhotoPass = Photopass;
exports.CloseApplication=CloseApp;
