/* This is the main Script containing the initialization of all individual test
   case scripts.
*/
describe('Welcome to disney app testing', function () {

    before(function () {
        try{
        this.timeout(1000000);
        //return client.init();
        console.log("Login Testing Begins...");
      }catch(err){
        console.log(err);
        this.skip();
      }
      });
    
    
    after(function () {
    	this.timeout(100000);
        let TCase1 = require('./Login/Login_TC1');
        return TCase1.CloseApplication();
    });

  /*    afterEach("take screenshot on failure", function() {
        if (this.currentTest.state !== "passed") {
          //this.timeout(900000);
          //getCurrentDate = Date.now();
          var imageFileName = this.currentTest.title + '.png';
          return client.saveScreenshot('./mochawesome-reports/screenshots/'+ imageFileName);

        }
      });*/

      it("LaunchApplication"+"_"+Date.now(), function(){
        this.timeout(100000);
        let TCase1 = require('./Login/Login_TC1');
        return TCase1.LaunchApplication();
          });
      
      it("LoginApplication"+"_"+Date.now(), function(){
          this.timeout(100000);
          let TCase1 = require('./Login/Login_TC1');
          return TCase1.Login();
            });

      it("PhotoPass"+"_"+Date.now(), function(){
          this.timeout(100000);
          let TCase1 = require('./Login/Login_TC1');
          return TCase1.PhotoPass();
            });
      
      

});
