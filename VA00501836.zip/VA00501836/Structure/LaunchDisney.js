var modules = require('./config/requiredModules.js');
var client = modules.webdriverio.remote(modules.config);
/*var expect = require('chai').expect;
var config = require('./helpers/desiredCapabilities').options;
var client = webdriverio.remote(config);
var fs = require('fs');*/
//const mochaAwesome = require('mochawesome-screenshots/mochawesome');

describe('Launching Application', function () {
	 before(function () {
	        this.timeout(50000);
			console.log("Inside before method, launching application...")
	        return client.init();
	    });
	 it("Passed case"+"_"+Date.now(), function () { 
		   	console.log("Passed");
		   });
	
   it("Clicking on Pulldown menu"+"_"+Date.now(), function () { 
   	this.timeout(50000);
   	return client
   	.pause(10000)
   	.touchAction('android=new UiSelector().resourceId("com.disney.wdw.android:id/pulldown_image")','tap');
   });
   
   it("Clicking on Ok Alert"+"_"+Date.now(), function () { 
	   	this.timeout(50000);
	   	return client
	   	.pause(10000)
	   	.touchAction('android=new UiSelector().resourceId("com.disney.wdw.android:id/button1")','tap');
	   });
   
  afterEach("take screenshot on failure", function() {
       if (this.currentTest.state !== "passed") {
    	   var imageFileName = this.currentTest.title+'.jpeg';
    	   client.saveScreenshot('./mochawesome-reports/screenshots/'+imageFileName);
       }
   });
});