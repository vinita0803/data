//These are desired capabilities for Android and iOS

exports.Android = {
	desiredCapabilities: {
	platformName: 'Android',
    platformVersion: '6.0',
    appPackage: 'com.disney.wdw.android',
    appActivity: 'com.disney.wdpro.park.activities.LoaderActivity',
    deviceName: 'Nexus 6',
    udid: 'emulator-5554',
    unicodeKeyboard: true,
    resetKeyboard: true,
    clearSystemFiles: true
	},
	host:'localhost',
	port:4723
};	
