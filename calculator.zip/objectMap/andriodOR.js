/* Naming convention should be pagename_elementwithtype.Please follow the same
   acrros your scripts
*/

exports.calOR =
{
    cal_digit1: 'android=new UiSelector().resourceId("com.candl.athena:id/digit1")',
    cal_digit2: 'android=new UiSelector().resourceId("com.candl.athena:id/digit2")',
    cal_digit3: 'android=new UiSelector().resourceId("com.candl.athena:id/digit3")',
    cal_digit4 :'android=new UiSelector().resourceId("com.candl.athena:id/digit4")',
    cal_digit5: 'android=new UiSelector().resourceId("com.candl.athena:id/digit5")',
    cal_digit6: 'android=new UiSelector().resourceId("com.candl.athena:id/digit6")',
    cal_digit7: 'android=new UiSelector().resourceId("com.candl.athena:id/digit7")',
    cal_digit8: 'android=new UiSelector().resourceId("com.candl.athena:id/digit8")',
    cal_digit9: 'android=new UiSelector().resourceId("com.candl.athena:id/digit9")',
    cal_digit0: 'android=new UiSelector().resourceId("com.candl.athena:id/digit0")',
    cal_plus:  'android=new UiSelector().resourceId("com.candl.athena:id/plus")',
    cal_minus: 'android=new UiSelector().resourceId("com.candl.athena:id/minus")',
    cal_divide: 'android=new UiSelector().resourceId("com.candl.athena:id/div")',
    cal_multiply: 'android=new UiSelector().resourceId("com.candl.athena:id/mul")',
    cal_equal: 'android=new UiSelector().resourceId("com.candl.athena:id/equal")',

    cal_clear: 'android=new UiSelector().resourceId("com.candl.athena:id/clear")',
    cal_close: 'android=new UiSelector().resourceId("com.candl.athena:id/btn_close")',
}