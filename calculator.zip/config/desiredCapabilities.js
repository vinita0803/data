//These are desired capabilities for Android and iOS

exports.Android = {
	desiredCapabilities: {
	platformName: 'Android',
    platformVersion: '6.0.1',
    appPackage: 'com.candl.athena',
    appActivity: 'com.candl.athena.activity.Calculator',
    deviceName: 'LG5',
    udid: 'LGH8605b04963d',
    unicodeKeyboard: true,
    resetKeyboard: true,
    clearSystemFiles: true
	},
	host:'localhost',
    port:4723,
    };