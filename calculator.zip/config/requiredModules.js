// These are required packages needed for the scripts . Add your packages and import this file.

module.exports =
{
    calOR: require('../objectMap/andriodOR.js').calOR,
    config: require('./desiredCapabilities.js').Android,
    webdriverio: require('webdriverio'),
    expect: require('chai').expect,
    operations: require('../Lib/Calculations.js'),
    helperFunctions: require('../Lib/helperfunction.js'),
}