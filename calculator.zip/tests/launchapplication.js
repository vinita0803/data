var modules = require('../config/requiredModules.js');
var driver = modules.webdriverio.remote(modules.config);


describe('CALCU Testing', function () {

    before(function () {
        this.timeout(50000);
        return driver.init();
    });

    it("CALCULATOR ADD Postive", function () {
        this.timeout(900000);
        return driver.
        pause(5000)
        .click(modules.calOR.cal_close)
      .then(function(){
        return modules.operations.add("Adding two postive numbers",driver,modules);
         pause(5000)
        driver.click(modules.calOR.cal_clear);
      })
    });
   
    it("CALCULATOR ADD Negative", function () {
        this.timeout(900000);
        return driver.
        pause(5000)
      .then(function(){
        return modules.operations.addnegative("Adding two negative numbers",driver,modules);
         pause(5000)
        driver.click(modules.calOR.cal_clear);
      })
    });

    it("CALCULATOR ADD Negatve & Postive", function () {
        this.timeout(900000);
        return driver.
        pause(5000)
      .then(function(){
        return modules.operations.addnegpov("Adding one negative & one positive number",driver,modules);
         pause(5000)
        driver.click(modules.calOR.cal_clear);
      })
    });
    
    it("CALCULATOR Minus", function () {
        this.timeout(900000);
        return driver.
        pause(5000)
      .then(function(){
        return modules.operations.minus("Sustracting two postive numbers",driver,modules);
         pause(5000)
        driver.click(modules.calOR.cal_clear);
      })
    });

    it("CALCULATOR Divide", function () {
        this.timeout(900000);
        return driver.
        pause(5000)
      .then(function(){
        return modules.operations.divide("Dividing two postive numbers",driver,modules);
         pause(5000)
        driver.click(modules.calOR.cal_clear);
      })
    });

    it("CALCULATOR Multiply Postive", function () {
        this.timeout(900000);
        return driver.
        pause(5000)
      .then(function(){
        return modules.operations.multiply("Multiplying two postive numbers",driver,modules);
         pause(5000)
        driver.click(modules.calOR.cal_clear);
      })
    });

    it("CALCULATOR Multiply Negative", function () {
        this.timeout(900000);
        return driver.
        pause(5000)
      .then(function(){
        return modules.operations.multiplyneg("Multiplying two negative numbers",driver,modules);
         pause(5000)
        driver.click(modules.calOR.cal_clear);
      })
    });

    it("CALCULATOR Multiply Negative & Postive", function () {
        this.timeout(900000);
        return driver.
        pause(5000)
      .then(function(){
        return modules.operations.multiplynegpov("Multiplying one negative & one positive number",driver,modules);
         pause(5000)
        driver.click(modules.calOR.cal_clear);
      })
    });

    afterEach(function(){
        this.timeout(5000);
        driver.click(modules.calOR.cal_clear);
        if (this.currentTest.state !== "passed") {
          return modules.helperFunctions.screenshot(driver);
        }
    });
    after(function() {
        this.timeout(50000);
       return driver.end();
    });
});